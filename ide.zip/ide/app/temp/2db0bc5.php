<?php 

$i = 2;
$j = 3;

if($i < $j) echo "Hi";
else echo "Hello";