for(i = 0; i< 100; i++) {
    
    if(i % 2 == 0) console.log(i + " : Even");
    else console.log(i + " : Odd");
}