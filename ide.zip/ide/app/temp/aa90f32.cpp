#include <iostream>

int main() {
    std::cout << "hello World C++";
    return 1;
}