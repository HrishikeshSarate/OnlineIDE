for(i = 0; i< 100; i++) {
    
    if(i % 2 == 0) console.log(i + " : Even \n");
    else console.log(i + " : Odd\n");
}